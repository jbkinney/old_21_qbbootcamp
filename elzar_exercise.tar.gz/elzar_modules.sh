module purge
module load uge
module load EBModules
module load BWA/0.7.17-GCC-9.3.0
module load SAMtools/1.11-GCC-9.3.0
